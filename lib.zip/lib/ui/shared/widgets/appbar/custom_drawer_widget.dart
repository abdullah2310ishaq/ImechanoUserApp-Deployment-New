// ignore_for_file: camel_case_types, deprecated_member_use

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:imechano/localization/language_constrants.dart';
import 'package:imechano/ui/common/globals.dart' as globals;
import 'package:imechano/ui/privacy_disp.dart';
import 'package:imechano/ui/provider/notification_count_provider.dart';
import 'package:imechano/ui/provider/theme_provider.dart';
import 'package:imechano/ui/screens/auth/sign_in/view/sign_in_screen.dart';
import 'package:imechano/ui/screens/bottombar/My_Bookings_Page.dart';
import 'package:imechano/ui/screens/bottombar/bottom_bar.dart';
import 'package:imechano/ui/screens/bottombar/my%20invoice.dart';
import 'package:imechano/ui/screens/bottombar/my_job_card.dart';
import 'package:imechano/ui/screens/bottombar/profile.dart';
import 'package:imechano/ui/screens/choose_language.dart';
import 'package:imechano/ui/screens/location/location_map.dart';
import 'package:imechano/ui/screens/my_account/Notification.dart';
import 'package:imechano/ui/screens/my_account/faq.dart';
import 'package:imechano/ui/screens/my_account/home.dart';

import 'package:imechano/ui/screens/select_car/view/my_vehical_screen.dart';
import 'package:imechano/ui/share_preferences/pref_key.dart';
import 'package:imechano/ui/share_preferences/preference.dart';
import 'package:imechano/ui/styling/colors.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../styling/config.dart';

class drawerpage extends StatefulWidget {
  @override
  State<drawerpage> createState() => _drawerpageState();
}

class _drawerpageState extends State<drawerpage> {
  List drawerGuestIcon = [];
  List drawerTitle = [];
  var userStr;

  var profileData;
  var profilename = "James";
  var userphoneno = "0000";
  var profileurl = "";
  bool isSwitch = false;
  var address;
  var dataLoad;
  final GlobalKey<ScaffoldState> _key = GlobalKey();

  void getAddress() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      address = prefs.getString('address') ?? 'Select your address';

      dataLoad = true;

      print(address);
    });
  }

  List pageDrawer = [
    HomeScreen(),
    Myvehicalscreen(),
    MyBookingsPage(),
    MapLocation(
      callBackFunction: (mainAddress) {},
    ),
    MyInvoice(),
    MyJobCard(),
    NotificationScreen(),
    // PrivacyPolicyScreen(),
    PolicyScreen(
      mdFileName: 'term_privacy.md',
    )

    // AccordionPage(),
  ];

  List pageMyAccount = [
    BottomBarPage(2),
    ProfilePage(),
    BottomBarPage(0), //Myvehicalscreen(),
    // ProgressreportInactive(),
    BottomBarPage(1), //MyBookingsPage(),
    MapLocation(),
    MyInvoice(),
    BottomBarPage(3),
    NotificationScreen(),
    FAQsPage(),
    // AccordionPage(),
    PolicyScreen(mdFileName: 'term_privacy.md'),
    ChooseLanguage()
  ];

  Locale selectedLocale = Locale('en');

  @override
  void initState() {
    super.initState();
    userStr =
        PrefObj.preferences!.containsKey(PrefKeys.USER_DATA) ? true : false;
    if (userStr) {
      profileData =
          json.decode(PrefObj.preferences!.get(PrefKeys.PROFILE_DATA));
      profilename = profileData['name'].toString();
      userphoneno = profileData['mobile_number'].toString();
      profileurl = Config.profileurl + profileData['profile'].toString();

      drawerTitle = [
        "Home",
        "My Profile",
        "My Vehicle",
        "My Bookings",
        "My Location",
        "My Invoices",
        "job card",
        "Notification",
        "FAQs",
        "Privacy Policy",
        "Change Language",
        "Dark Theme",
        "Logout",
      ];
      drawerGuestIcon = [
        "assets/icons/My Account/noun_Home_4334361.png",
        "assets/icons/My Account/person_black_24dp.png",
        "assets/icons/My Account/Path 8567.png",
        "assets/icons/My Account/noun_calender_2189968.png",
        "assets/icons/My Account/location.png",
        "assets/icons/My Account/file-text.png",
        "assets/icons/My Account/Desk_alt_fill.png",
        "assets/icons/My Account/notifications_black_24dp.png",
        "assets/icons/My Account/Desk_alt_fill.png",
        "assets/icons/My Account/Chield_check_fill.png",
        "assets/icons/My Account/language.png",
        "assets/icons/My Account/Path 131.png",
        "assets/icons/My Account/Sign_in.png",
      ];
    } else {
      // Guest mode: only show Home, FAQs, Privacy Policy
      drawerTitle = [
        "Home",
        "FAQs",
        "Privacy Policy",
      ];

      drawerGuestIcon = [
        "assets/icons/My Account/noun_Home_4334361.png",
        "assets/icons/My Account/Desk_alt_fill.png",
        "assets/icons/My Account/Chield_check_fill.png",
      ];
    }
  }

  dynamic appModelTheme;
  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context);
    appModelTheme = appModel;
    
    // Get screen dimensions for responsive design
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;
    
    return Drawer(
      key: _key,
      backgroundColor:
          appModelTheme.darkTheme ? const Color(0xFF252525) : Colors.white,
      width: isTablet ? 400.w : null, // Wider drawer on tablets
      child: ScreenUtilInit(
        designSize: isTablet ? Size(768, 1024) : Size(414, 896),
        builder: (context, child) => Column(
          children: [
            userStr
                ? Container(
                    height: isTablet ? 220.h : 186.h,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: logoBlue,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(30),
                          bottomLeft: Radius.circular(30)),
                    ),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          PrefObj.preferences!.containsKey(PrefKeys.PROFILE_IMG)
                              ? Center(
                                  child: CircleAvatar(
                                    radius: isTablet ? 70.h : 55.h,
                                    backgroundImage: NetworkImage(PrefObj
                                        .preferences!
                                        .get(PrefKeys.PROFILE_IMG)),
                                  ),
                                )
                              : Center(
                                  child: CircleAvatar(
                                    radius: isTablet ? 70.h : 55.h,
                                    child: Icon(Icons.person, size: isTablet ? 65.sp : 50.sp),
                                  ),
                                ),
                          SizedBox(
                            width: isTablet ? 30.w : 20.w,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                profilename.toUpperCase(),
                                style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontFamily: "Montserrat3  ",
                                    color: Colors.white,
                                    fontSize: isTablet ? 22.sp : 18.sp),
                              ),
                              Text(
                                userphoneno,
                                style: TextStyle(
                                    color: Colors.white, fontSize: isTablet ? 16.sp : 13.sp),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  )
                : Container(
                    height: isTablet ? 220.h : 186.h,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: logoBlue,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(30),
                          bottomLeft: Radius.circular(30)),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image(
                          image: AssetImage("assets/icons/splash/logo.png"),
                          height: isTablet ? 70.h : 50.h,
                        ),
                        SizedBox(
                          height: isTablet ? 20.h : MediaQuery.of(context).size.height * 0.02,
                        ),
                        Container(
                          height: isTablet ? 60.h : MediaQuery.of(context).size.height * 0.04,
                          decoration: BoxDecoration(
                            border: Border.all(),
                          ),
                          child: MaterialButton(
                            child: Text("Login", style: TextStyle(fontSize: isTablet ? 18.sp : 14.sp)),
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(
                                builder: (context) {
                                  return SignInScreen();
                                },
                              ));
                            },
                          ),
                        )
                      ],
                    ),
                  ),
            Expanded(
              child: Container(
                  child: NotificationListener<OverscrollIndicatorNotification>(
                onNotification: (notification) {
                  notification.disallowIndicator();
                  return true;
                },
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      // Drawer items
                      ListView.separated(
                          shrinkWrap: true,
                          padding: EdgeInsets.zero,
                          physics: const NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            // Simplified guest behavior: only 3 items
                            if (!userStr) {
                              return ListTile(
                                contentPadding:
                                    EdgeInsets.fromLTRB(isTablet ? 40.w : 30.w, 0, isTablet ? 40.w : 30.w, 0),
                                leading: SizedBox(
                                  height: isTablet ? 35.h : 25.h,
                                  child: Image(
                                      image: AssetImage(drawerGuestIcon[index])),
                                ),
                                title: Text(
                                  getTranslated(
                                      drawerTitle[index]
                                          .toString()
                                          .removeAllWhitespace
                                          .toLowerCase(),
                                      context),
                                  style: TextStyle(
                                      fontFamily: "Poppins1", fontSize: isTablet ? 18.sp : 15.sp),
                                ),
                                onTap: () {
                                  // Close drawer before navigating
                                  Navigator.of(context).pop();
                                  if (index == 0) {
                                    // Home - always navigate to BottomBarPage with home index
                                    Navigator.of(context).pushAndRemoveUntil(
                                        MaterialPageRoute(
                                            builder: (context) => BottomBarPage(2)),
                                        (Route<dynamic> route) => false);
                                  } else if (index == 1) {
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => FAQsPage()));
                                  } else if (index == 2) {
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => PolicyScreen(
                                                  mdFileName: 'term_privacy.md',
                                                )));
                                  }
                                },
                              );
                            }
                            // Logged-in special handling for Dark Theme: tap to toggle (no switch)
                            final String _titleRaw =
                                drawerTitle[index].toString();
                            if (userStr && _titleRaw == 'Dark Theme') {
                              final bool isDark = appModelTheme.darkTheme;
                              return ListTile(
                                contentPadding:
                                    EdgeInsets.fromLTRB(isTablet ? 40.w : 30.w, 0, isTablet ? 40.w : 30.w, 0),
                                leading: SizedBox(
                                  height: isTablet ? 35.h : 25.h,
                                  child: Image(
                                      image: AssetImage(drawerGuestIcon[index])),
                                ),
                                title: Text(
                                  getTranslated(
                                      _titleRaw.toLowerCase().removeAllWhitespace,
                                      context),
                                  style: TextStyle(
                                      fontFamily: "Poppins1",
                                      fontSize: isTablet ? 18.sp : 15.sp,
                                      color: isDark
                                          ? Colors.white
                                          : const Color(0xFF374049)),
                                ),
                                trailing: Icon(
                                  isDark
                                      ? Icons.wb_sunny_rounded
                                      : Icons.dark_mode_rounded,
                                  color: isDark ? Colors.white70 : Colors.black54,
                                  size: isTablet ? 28.sp : 24.sp,
                                ),
                                onTap: () {
                                  setState(() {
                                    appModelTheme.darkTheme =
                                        !appModelTheme.darkTheme;
                                  });
                                  // Close drawer and navigate to home to refresh the responsive UI
                                  Navigator.of(context).pop();
                                  // Navigate to home with full rebuild to fix responsive sizing
                                  Navigator.of(context).pushAndRemoveUntil(
                                      MaterialPageRoute(
                                          builder: (context) => BottomBarPage(2)),
                                      (Route<dynamic> route) => false);
                                },
                              );
                            }
                            return GestureDetector(
                              onTap: () {
                                if (userStr ? index == 11 : index == 12) {
                                  Container();
                                } else {
                                  if (index == 12) {
                                    logOutDialog();
                                  } else if (index == 10) {
                                    Container();
                                  } else if (index == 0) {
                                    Navigator.of(context).pushAndRemoveUntil(
                                        MaterialPageRoute(
                                            builder: (context) => userStr
                                                ? pageMyAccount[index]
                                                : pageDrawer[index]),
                                        (Route<dynamic> route) => false);
                                  } else {
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => userStr
                                                ? pageMyAccount[index]
                                                : pageDrawer[index]));
                                  }
                                }
                              },
                              child: index == drawerGuestIcon.length - 3
                                  ? ListTile(
                                      trailing: Switch(
                                        value: globals.langSwitch,
                                        onChanged: (value) {
                                          setState(() {
                                            if (globals.langSwitch) {
                                              globals.changeLocale(
                                                  profileData['id'], 'en');
                                              selectedLocale = Locale('en');
                                              appModel
                                                  .changeLanguage(selectedLocale);

                                              globals.langSwitch = false;
                                            } else {
                                              globals.changeLocale(
                                                  profileData['id'], 'ar');
                                              selectedLocale = Locale('ar');
                                              appModel
                                                  .changeLanguage(selectedLocale);
                                              globals.langSwitch = true;
                                            }
                                          });
                                          // Navigate to home to refresh the responsive UI after language change
                                          Navigator.of(context).pushAndRemoveUntil(
                                              MaterialPageRoute(
                                                  builder: (context) => BottomBarPage(2)),
                                              (Route<dynamic> route) => false);
                                        },
                                        activeColor: logoBlue,
                                        activeTrackColor: buttonBlue3b5999,
                                        inactiveThumbColor: Colors.grey,
                                        inactiveTrackColor: Colors.black26,
                                      ),
                                      contentPadding:
                                          EdgeInsets.fromLTRB(isTablet ? 40.w : 30.w, 0, isTablet ? 40.w : 30.w, 0),
                                      leading: SizedBox(
                                        height: isTablet ? 35.h : 25.h,
                                        child: Image(
                                            image: AssetImage(
                                                drawerGuestIcon[index])),
                                      ),
                                      title: Text(
                                        getTranslated(
                                            drawerTitle[index]
                                                .toString()
                                                .removeAllWhitespace
                                                .toLowerCase(),
                                            context),
                                        style: TextStyle(
                                            fontFamily: "Poppins1", fontSize: isTablet ? 18.sp : 15.sp),
                                      ),
                                    )
                                  : ListTile(
                                      trailing: userStr
                                          ? index == drawerGuestIcon.length - 2
                                              ? switchButton(isTablet)
                                              : Text("")
                                          : index == drawerGuestIcon.length - 1
                                              ? switchButton(isTablet)
                                              : Text(""),
                                      contentPadding:
                                          EdgeInsets.fromLTRB(isTablet ? 40.w : 30.w, 0, isTablet ? 40.w : 30.w, 0),
                                      leading: SizedBox(
                                        height: isTablet ? 35.h : 25.h,
                                        child: Image(
                                            image: AssetImage(
                                                drawerGuestIcon[index])),
                                      ),
                                      title: Text(
                                        getTranslated(
                                            drawerTitle[index]
                                                .toString()
                                                .removeAllWhitespace
                                                .toLowerCase(),
                                            context),
                                        style: TextStyle(
                                            fontFamily: "Poppins1", fontSize: isTablet ? 18.sp : 15.sp),
                                      ),
                                    ),
                            );
                          },
                          separatorBuilder: (context, index) {
                            return Container(height: 0, child: Divider());
                          },
                          itemCount: drawerGuestIcon.length),
                    ],
                  ),
                ),
              )),
            ),
          ],
        ),
      ),
    );
  }

  Widget languageSwitch() {
    return Switch(
      value: appModelTheme.darkTheme,
      onChanged: (value) {
        setState(() {
          appModelTheme.darkTheme = !appModelTheme.darkTheme;

          //isSwitch = value;
          isSwitch
              ? ThemeData(
                  brightness: Brightness.dark,
                  /* light theme settings */
                )
              : ThemeData(
                  brightness: Brightness.light,
                  /* dark theme settings */
                );
          isSwitch = value;
        });
      },
    );
  }

  Widget switchButton([bool isTablet = false]) {
    return Switch(
      value: appModelTheme.darkTheme,
      onChanged: (value) {
        setState(() {
          appModelTheme.darkTheme = !appModelTheme.darkTheme;

          //isSwitch = value;
          isSwitch
              ? ThemeData(
                  brightness: Brightness.dark,
                )
              : ThemeData(
                  brightness: Brightness.light,
                );
          isSwitch = value;
        });
        // Navigate to home to refresh the responsive UI after theme change
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(
                builder: (context) => BottomBarPage(2)),
            (Route<dynamic> route) => false);
      },
      activeColor: logoBlue,
      activeTrackColor: buttonBlue3b5999,
      inactiveThumbColor: Colors.grey,
      inactiveTrackColor: Colors.black26,
    );
  }

  // Widget switchLangButton() {
  //   return Switch(
  //     value: appModelTheme.darkTheme,
  //     onChanged: (value) {
  //       setState(() {
  //         if (isSwitch) {
  //           selectedLocale = Locale('en');
  //           appModel.changeLanguage(selectedLocale);
  //         }
  //         isSwitch = value;
  //         print(isSwitch);
  //       });
  //     },
  //   );
  // }

  void logOutDialog() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Center(
              child: Column(
            children: [
              Text(
                getTranslated("logout", context) + " ?",
                style: TextStyle(
                  fontFamily: "Poppins2", 
                  fontSize: isTablet ? 20.sp : 16.sp
                ),
              ),
              SizedBox(height: isTablet ? 20.h : 15.h),
              Text(
                getTranslated("Areyousureyouwanttologout?", context),
                style: TextStyle(
                  fontSize: isTablet ? 18.sp : 15.sp, 
                  fontFamily: "Poppins1"
                ),
              )
            ],
          )),
          actions: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                    // textColor: Colors.black,
                    child: Text(
                      getTranslated("cancel", context),
                      style: TextStyle(
                        color: logoBlue, 
                        fontFamily: "Poppins1",
                        fontSize: isTablet ? 16.sp : 14.sp
                      ),
                    ),
                    onPressed: () {
                      Navigator.of(context).pop();
                    }),
                TextButton(
                    child: Text(getTranslated('logout', context),
                        style: TextStyle(
                            color: Colors.redAccent, 
                            fontFamily: "Poppins1",
                            fontSize: isTablet ? 16.sp : 14.sp)),
                    onPressed: () {
                      Provider.of<NotificationCountProvider>(context,
                              listen: false)
                          .clearNotifications();
                      globals.changeLocale(PrefKeys.USER_ID, "en");
                      PrefObj.preferences?.clear();
                      PrefObj.preferences?.put(PrefKeys.APPSTARTED, true);

                      Navigator.of(context).pushNamedAndRemoveUntil(
                          '/sign-in-sign-up-landing', (Route route) => false);
                    })
              ],
            ),
          ],
        );
      },
    );
  }
}