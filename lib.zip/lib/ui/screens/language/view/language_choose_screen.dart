import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:imechano/localization/language_constrants.dart';
import 'package:imechano/ui/provider/theme_provider.dart';
import 'package:imechano/ui/share_preferences/pref_key.dart';
import 'package:imechano/ui/share_preferences/preference.dart';
import 'package:imechano/ui/shared/widgets/buttons/custom_button.dart';
import 'package:imechano/ui/styling/colors.dart';
import 'package:provider/provider.dart';

class LanguageChooseScreen extends StatefulWidget {
  const LanguageChooseScreen({Key? key}) : super(key: key);

  @override
  State<LanguageChooseScreen> createState() => _LanguageChooseScreenState();
}

class _LanguageChooseScreenState extends State<LanguageChooseScreen> {
  // bool myvalue = false;
  dynamic appModelTheme;

  Locale selectedLocale = Locale('en');

  Future<bool> _onWillPop() async {
    return (await showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(getTranslated('exitapp', context)),
            content: Text(getTranslated('doyouwanttoexitanapp', context)),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text(getTranslated('no', context)),
              ),
              TextButton(
                onPressed: () {
                  SystemNavigator.pop(); // Exits the app on Yes press
                },
                child: Text(getTranslated('yes', context)),
              ),
            ],
          ),
        )) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    final appModel = Provider.of<AppModel>(context);
    appModelTheme = appModel;
    
    // Screen responsive variables
    final isTablet = size.width > 600;
    
    return WillPopScope(
      onWillPop: _onWillPop,
      child: ScreenUtilInit(
        designSize: isTablet ? Size(768, 1024) : Size(414, 896),
        builder: (context, child) => Scaffold(
          backgroundColor: appModelTheme.darkTheme ? Color(0xff252525) : white,
          body: SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: constraints.maxHeight,
                    ),
                    child: IntrinsicHeight(
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(horizontal: 20.w),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            // Spacer top
                            Spacer(flex: isTablet ? 2 : 3),
                            
                            // Title section
                            Column(
                              children: [
                                Text(
                                  getTranslated('ChooseYour', context),
                                  style: TextStyle(
                                    fontFamily: "Poppins5",
                                    fontSize: isTablet ? 30.sp : 26.sp,
                                    color: appModelTheme.darkTheme ? Colors.white : Colors.black,
                                  ),
                                ),
                                Text(
                                  getTranslated('Preferred', context),
                                  style: TextStyle(
                                    fontFamily: "Poppins5",
                                    fontSize: isTablet ? 30.sp : 26.sp,
                                    color: appModelTheme.darkTheme ? Colors.white : Colors.black,
                                  ),
                                ),
                              ],
                            ),
                            
                            SizedBox(height: isTablet ? 50.h : 40.h),
                            
                            // English button
                            SizedBox(
                              height: isTablet ? 65.h : 58.h,
                              child: CustomButton(
                                title: Text(
                                  'English',
                                  style: TextStyle(
                                    fontFamily: "Montserrat2",
                                    fontSize: isTablet ? 18.sp : 16.sp,
                                  ),
                                ),
                                width: isTablet ? 0.6 : 0.8,
                                bgColor: appModel.appLocal == Locale('en')
                                    ? logoBlue
                                    : grayE6E6E5,
                                borderColor: transparent,
                                callBackFunction: () {
                                  setState(() {
                                    selectedLocale = Locale('en');
                                    appModel.changeLanguage(selectedLocale);
                                  });
                                },
                              ),
                            ),
                            
                            SizedBox(height: isTablet ? 25.h : 30.h),
                            
                            // Arabic button
                            SizedBox(
                              height: isTablet ? 65.h : 58.h,
                              child: CustomButton(
                                title: Text(
                                  'عربي',
                                  style: TextStyle(
                                    fontFamily: "Montserrat2",
                                    fontSize: isTablet ? 24.sp : 20.sp,
                                  ),
                                ),
                                width: isTablet ? 0.6 : 0.8,
                                bgColor: appModel.appLocal == Locale('ar')
                                    ? logoBlue
                                    : grayE6E6E5,
                                borderColor: transparent,
                                callBackFunction: () {
                                  setState(() {
                                    selectedLocale = Locale('ar');
                                    appModel.changeLanguage(selectedLocale);
                                  });
                                },
                              ),
                            ),
                            
                            // Spacer middle
                            Spacer(flex: isTablet ? 2 : 4),
                            
                            // Information text section
                            Column(
                              children: [
                                Text(
                                  getTranslated('langmsg', context),
                                  style: TextStyle(
                                    fontFamily: "Poppins3", 
                                    fontSize: isTablet ? 16.sp : 15.sp,
                                    color: Colors.grey[600],
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                SizedBox(height: 4.h),
                                Text(
                                  getTranslated('langmsg2', context),
                                  style: TextStyle(
                                    fontFamily: "Poppins3", 
                                    fontSize: isTablet ? 16.sp : 15.sp,
                                    color: Colors.grey[600],
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                            
                            SizedBox(height: isTablet ? 35.h : 30.h),
                            
                            // Continue button
                            SizedBox(
                              height: isTablet ? 65.h : 60.h,
                              child: CustomButton(
                                title: Text(
                                  getTranslated("Continue", context),
                                  style: TextStyle(
                                    fontSize: isTablet ? 20.sp : 18.sp,
                                    fontFamily: 'Poppins1',
                                  ),
                                ),
                                width: isTablet ? 0.6 : 0.8,
                                bgColor: appModelTheme.darkTheme ? darkmodeColor : logoBlue,
                                borderColor: appModelTheme.darkTheme
                                    ? darkmodeColor
                                    : buttonBlueBorder,
                                callBackFunction: () {
                                  appModel.changeLanguage(selectedLocale);
                                  PrefObj.preferences!.put(PrefKeys.APPSTARTED, true);
                                  Get.offNamed('/on-boarding');
                                },
                              ),
                            ),
                            
                            // Spacer bottom
                            Spacer(flex: 1),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}