import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/route_manager.dart';
import 'package:imechano/localization/language_constrants.dart';
import 'package:imechano/ui/provider/theme_provider.dart';
import 'package:imechano/ui/screens/auth/sign_in/view/sign_in_screen.dart';
import 'package:imechano/ui/screens/bottombar/bottom_bar.dart';
import 'package:imechano/ui/screens/privacy_policy/terms_of_use.dart';
import 'package:imechano/ui/shared/widgets/buttons/custom_button.dart';
import 'package:imechano/ui/styling/colors.dart';
import 'package:provider/provider.dart';

import '../../../language/view/language_choose_screen.dart';

class SignInSignUpLandingScreen extends StatefulWidget {
  const SignInSignUpLandingScreen({Key? key}) : super(key: key);

  @override
  State<SignInSignUpLandingScreen> createState() =>
      _SignInSignUpLandingScreenState();
}

class _SignInSignUpLandingScreenState extends State<SignInSignUpLandingScreen> {
  dynamic appModelTheme;

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context);
    appModelTheme = appModel;
    
    // Get screen dimensions
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final isTablet = screenWidth > 600;
    final isLandscape = screenWidth > screenHeight;
    
    return WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => LanguageChooseScreen()),
          );
          return false; // Prevents default back button behavior
        },
        child: Scaffold(
          backgroundColor: appModelTheme.darkTheme ? Color(0xff252525) : white,
          body: ScreenUtilInit(
            designSize: isTablet ? Size(768, 1024) : Size(414, 896),
            builder: (context, child) => SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: constraints.maxHeight,
                      ),
                      child: IntrinsicHeight(
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: isTablet ? 60.w : 20.w, 
                              vertical: isTablet ? 20.h : 10.h),
                          child: isLandscape && isTablet 
                              ? _buildLandscapeLayout()
                              : _buildPortraitLayout(isTablet),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ));
  }

  // Portrait layout for both phone and tablet
  Widget _buildPortraitLayout(bool isTablet) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Flexible(
          flex: 2,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                child: Image(
                    height: isTablet ? 120.h : 80.h,
                    image: AssetImage('assets/icons/splash/logo.png'),
                    color: appModelTheme.darkTheme ? white : null),
              ),
              SizedBox(height: isTablet ? 30.h : 20.h),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.w),
                child: Center(
                  child: Text(
                      getTranslated("welcomemsg", context),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: isTablet ? 18.sp : 14.sp)),
                ),
              ),
            ],
          ),
        ),
        Flexible(
          flex: 3,
          child: Center(
            child: Image(
                height: isTablet ? 350.h : 250.h,
                image: AssetImage('assets/icons/auth/landing.png')),
          ),
        ),
        Flexible(
          flex: 2,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              buttonsSection(isTablet),
              SizedBox(height: isTablet ? 20.h : 12.h),
              CustomButton(
                title: Text(
                  getTranslated("guest", context),
                  style: TextStyle(
                      fontSize: isTablet ? 18.sp : 16.sp,
                      fontFamily: 'Poppins1',
                      color: Colors.white),
                ),
                width: isTablet ? 0.6 : 0.85,
                height: isTablet ? 56 : 44,
                callBackFunction: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) {
                      return BottomBarPage(2);
                    },
                  ));
                },
                bgColor: logoBlue,
                borderColor: logoBlue,
              ),
              SizedBox(height: isTablet ? 16.h : 8.h),
              FittedBox(child: TermsOfUse()),
            ],
          ),
        ),
      ],
    );
  }

  // Landscape layout for tablets
  Widget _buildLandscapeLayout() {
    return Row(
      children: [
        Expanded(
          flex: 1,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                child: Image(
                    height: 100.h,
                    image: AssetImage('assets/icons/splash/logo.png'),
                    color: appModelTheme.darkTheme ? white : null),
              ),
              SizedBox(height: 20.h),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Text(
                    getTranslated("welcomemsg", context),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16.sp)),
              ),
              SizedBox(height: 30.h),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 40.w),
                child: Column(
                  children: [
                    buttonsSection(true),
                    SizedBox(height: 20.h),
                    CustomButton(
                      title: Text(
                        getTranslated("guest", context),
                        style: TextStyle(
                            fontSize: 16.sp,
                            fontFamily: 'Poppins1',
                            color: Colors.white),
                      ),
                      width: 0.8,
                      height: 48,
                      callBackFunction: () {
                        Navigator.push(context, MaterialPageRoute(
                          builder: (context) {
                            return BottomBarPage(2);
                          },
                        ));
                      },
                      bgColor: logoBlue,
                      borderColor: logoBlue,
                    ),
                    SizedBox(height: 16.h),
                    FittedBox(child: TermsOfUse()),
                  ],
                ),
              ),
            ],
          ),
        ),
        Expanded(
          flex: 1,
          child: Center(
            child: Image(
                height: 300.h,
                image: AssetImage('assets/icons/auth/landing.png')),
          ),
        ),
      ],
    );
  }

  Widget buttonsSection([bool isTablet = false]) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 5.w),
            child: CustomButton(
              title: Text(
                getTranslated('signin', context),
                style: TextStyle(
                    fontSize: isTablet ? 16.sp : 14.sp,
                    fontFamily: 'Poppins1',
                    color: Colors.white),
              ),
              width: 1.0,
              height: isTablet ? 52 : 44,
              callBackFunction: () {
                setState(() {
                  appModelTheme.checkCon = false;
                });
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return SignInScreen();
                  },
                ));
              },
              bgColor: buttonNaviBlue162e3f,
              borderColor: buttonNaviBlue162e3f,
            ),
          ),
        ),
        orDividerSection(isTablet),
        Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 5.w),
            child: CustomButton(
              title: Text(
                getTranslated('Signup', context),
                style: TextStyle(
                    fontSize: isTablet ? 16.sp : 14.sp,
                    fontFamily: 'Poppins1',
                    color: Colors.white),
              ),
              width: 1.0,
              height: isTablet ? 52 : 44,
              callBackFunction: () {
                setState(() {
                  appModelTheme.checkCon = false;
                });
                Get.toNamed('/sign-up');
              },
              bgColor: buttonBlue3b5999,
              borderColor: buttonBlue3b5999,
            ),
          ),
        ),
      ],
    );
  }

  Widget orDividerSection([bool isTablet = false]) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 8.h),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: isTablet ? 16.h : 12.h,
            child: VerticalDivider(
              width: 10,
              color: appModelTheme.darkTheme ? white : Color(0xff374049),
              thickness: 1.5,
            ),
          ),
          Text(
            getTranslated("OR", context),
            style: TextStyle(
              fontSize: isTablet ? 14.sp : 12.sp,
              fontFamily: 'Poppins1',
              color: appModelTheme.darkTheme ? white : Color(0xff374049),
            ),
          ),
          Container(
            height: isTablet ? 16.h : 12.h,
            child: VerticalDivider(
              width: 10,
              color: appModelTheme.darkTheme ? white : Color(0xff374049),
              thickness: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}
